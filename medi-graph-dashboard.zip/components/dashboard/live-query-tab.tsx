'use client'

import { useState } from 'react'
import { ChevronRight } from 'lucide-react'

const queries = [
  {
    label: 'Single hop',
    query: 'What is the mechanism of remdesivir?'
  },
  {
    label: 'Two hop',
    query: 'Which IL-6 inhibitors were tested in COVID-19 trials?'
  },
  {
    label: 'Three hop',
    query: 'What proteins targeted by anti-cancer drugs appear in COVID-19 trials?',
    isBest: true
  }
]

const answers = {
  'llm': 'Remdesivir is a nucleotide analog prodrug that inhibits viral RNA-dependent RNA polymerase (RdRp), preventing viral replication. It has been shown to reduce hospitalization duration in COVID-19 patients and is used under emergency authorization protocols.',
  'rag': 'Remdesivir is a nucleotide analog prodrug that inhibits viral RNA-dependent RNA polymerase. It has direct antiviral activity by incorporating into nascent viral RNA chains, causing chain termination. The mechanism relies on cellular enzymes for activation. Studies show it reduces viral titers and hospitalization duration in SARS-CoV-2 infected patients.',
  'graphrag': 'Remdesivir functions as a nucleotide analog that inhibits SARS-CoV-2 RNA-dependent RNA polymerase, leading to viral RNA chain termination. This mechanism is shared among several antiviral compounds. The graph-based search found that remdesivir targets the viral polymerase complex.'
}

const pipelines = [
  { id: 'llm', name: 'LLM-Only', color: '#ef4444', tokens: 282, latency: '4.1s', status: 'PASS' },
  { id: 'rag', name: 'Basic RAG', color: '#f59e0b', tokens: 963, latency: '5.6s', status: 'PASS' },
  { id: 'graphrag', name: 'GraphRAG', color: '#10b981', tokens: 205, latency: '2.3s', status: 'PASS' }
]

export function LiveQueryTab() {
  const [query, setQuery] = useState('')
  const [isRunning, setIsRunning] = useState(false)
  const [hasRun, setHasRun] = useState(false)

  const handleQuery = (selectedQuery: string) => {
    setQuery(selectedQuery)
  }

  const handleRun = () => {
    if (!query.trim()) return
    setIsRunning(true)
    setTimeout(() => {
      setIsRunning(false)
      setHasRun(true)
    }, 2500)
  }

  return (
    <div className="grid grid-cols-[1fr_1.5fr] gap-12">
      {/* LEFT COLUMN - Input Panel */}
      <div className="space-y-6">
        <div>
          <h2 className="text-base font-medium text-foreground mb-2">Run a query</h2>
          <p className="text-xs text-muted-foreground">Same question, three pipelines. Watch the token counts.</p>
        </div>

        <textarea
          placeholder="Ask a biomedical question..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full h-32 bg-card border border-border text-foreground placeholder-muted-foreground text-sm p-3 font-sans rounded focus:outline-none focus:ring-1 focus:ring-accent resize-none"
        />

        <div className="space-y-2">
          {queries.map((q) => (
            <button
              key={q.label}
              onClick={() => handleQuery(q.query)}
              className="w-full text-left text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2 group"
            >
              <ChevronRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              <span className="text-xs">{q.label}</span>
              {q.isBest && <span className="text-xs bg-secondary px-1.5 py-0.5 rounded text-muted-foreground ml-auto">best demo</span>}
            </button>
          ))}
        </div>

        <button
          onClick={handleRun}
          disabled={isRunning || !query.trim()}
          className="w-full py-2.5 px-4 bg-accent hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-background font-medium text-sm rounded transition-colors flex items-center justify-center gap-2"
        >
          Run all pipelines
          <ChevronRight className="w-3.5 h-3.5" />
        </button>

        <p className="text-xs text-muted-foreground">
          ~15 seconds · 3 Gemini calls · results saved
        </p>
      </div>

      {/* RIGHT COLUMN - Results Panel */}
      <div className="space-y-6">
        {hasRun ? (
          <>
            {/* Pipeline Results */}
            <div className="space-y-3">
              {pipelines.map((pipeline) => (
                <div
                  key={pipeline.id}
                  className={`p-4 border rounded flex gap-4 items-start ${
                    pipeline.id === 'graphrag'
                      ? 'border-accent bg-emerald-900/5 border-l-2'
                      : 'border-border'
                  }`}
                >
                  <div className="flex-1 space-y-2 min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: pipeline.color }} />
                      <span className="text-xs font-mono text-muted-foreground">{pipeline.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-3">
                      {answers[pipeline.id as keyof typeof answers]}
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <span className="text-xs font-mono text-foreground px-2 py-1 bg-secondary rounded">{pipeline.tokens} tok</span>
                    <span className="text-xs font-mono text-foreground px-2 py-1 bg-secondary rounded">{pipeline.latency}</span>
                    <span className="text-xs font-mono text-foreground px-2 py-1 bg-secondary rounded">{pipeline.status} ✓</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary Stat */}
            <div className="text-sm text-accent font-medium">
              GraphRAG used 78.7% fewer tokens than Basic RAG on this query
            </div>

            {/* Token Bar Visualization */}
            <div className="space-y-4 pt-4">
              {pipelines.map((pipeline) => (
                <div key={pipeline.id} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{pipeline.name}</span>
                    <span className="text-xs font-mono text-foreground">{pipeline.tokens}</span>
                  </div>
                  <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-1000 ease-out"
                      style={{
                        width: `${(pipeline.tokens / 963) * 100}%`,
                        backgroundColor: pipeline.color
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="h-64 flex items-center justify-center border border-border border-dashed rounded">
            <div className="text-center space-y-2">
              <p className="text-xs text-muted-foreground">Run a query to see results</p>
              <p className="text-xs text-muted-foreground">Compare token usage across pipelines</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
